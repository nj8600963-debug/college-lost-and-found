# CampusFind — College Lost & Found

A polished Python mini-project for a college-only Lost & Found portal.

## Features

- Student registration and login
- Secure password hashing with Werkzeug
- Lost / Found item reports
- Item categories and campus locations
- Search and filtering
- Individual item detail pages
- Contact information for the reporter
- Personal dashboard
- Mark a report as resolved
- SQLite database — no separate database server required
- Responsive dark UI with glass-style cards
- Lightweight CSS animations and radar-style landing visual

## Tech Stack

- Python
- Flask
- SQLite
- HTML5
- CSS3
- JavaScript

## Folder Structure

```text
campus_lost_found/
├── app/
│   ├── app.py
│   ├── lost_found.db          # created automatically after first run
│   ├── templates/
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── login.html
│   │   ├── register.html
│   │   ├── items.html
│   │   ├── post_item.html
│   │   ├── item_detail.html
│   │   └── dashboard.html
│   └── static/
│       ├── css/style.css
│       ├── js/app.js
│       └── images/
├── requirements.txt
├── run.py
└── README.md
```

## Run on Windows

1. Install Python 3.10+.
2. Open Command Prompt in this folder.
3. Create a virtual environment:

```bash
python -m venv venv
```

4. Activate it:

```bash
venv\Scripts\activate
```

5. Install packages:

```bash
pip install -r requirements.txt
```

6. Start the website:

```bash
python run.py
```

7. Open:

```text
http://127.0.0.1:5000
```

## College Demonstration Flow

1. Create two student accounts.
2. Account A posts a Lost item.
3. Account B browses/searches the board.
4. Account B posts a Found item.
5. Open an item to view the reporter's contact information.
6. The owner can mark their own report as Resolved from the dashboard.

## Important

This is a student mini-project. For real deployment, change the Flask secret key, use HTTPS, validate college email domains, add CSRF protection, use proper image uploads, and use a production WSGI server.
