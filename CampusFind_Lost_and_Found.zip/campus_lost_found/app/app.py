from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "lost_found.db"

app = Flask(__name__)
app.secret_key = "change-this-secret-key-for-production"


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        category TEXT NOT NULL,
        location TEXT NOT NULL,
        item_type TEXT NOT NULL CHECK(item_type IN ('Lost', 'Found')),
        contact TEXT NOT NULL,
        image_url TEXT DEFAULT '',
        user_id INTEGER NOT NULL,
        status TEXT DEFAULT 'Open',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    );
    """)
    conn.commit()
    conn.close()


@app.context_processor
def inject_user():
    return {"current_user": session.get("user")}


@app.route("/")
def index():
    conn = get_db()
    recent = conn.execute("""
        SELECT items.*, users.name AS owner_name
        FROM items JOIN users ON users.id = items.user_id
        WHERE items.status = 'Open'
        ORDER BY items.created_at DESC LIMIT 6
    """).fetchall()
    counts = conn.execute("""
        SELECT
            SUM(item_type='Lost') AS lost,
            SUM(item_type='Found') AS found,
            SUM(status='Resolved') AS resolved
        FROM items
    """).fetchone()
    conn.close()
    return render_template("index.html", recent=recent, counts=counts)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]

        if not name or not email or len(password) < 6:
            flash("Please fill all fields. Password must be at least 6 characters.", "error")
            return redirect(url_for("register"))

        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO users (name, email, password) VALUES (?, ?, ?)",
                (name, email, generate_password_hash(password))
            )
            conn.commit()
            flash("Account created. You can now log in.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That email is already registered.", "error")
        finally:
            conn.close()
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]

        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session["user"] = {"id": user["id"], "name": user["name"], "email": user["email"]}
            return redirect(url_for("dashboard"))

        flash("Invalid email or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))

    conn = get_db()
    my_items = conn.execute("""
        SELECT * FROM items WHERE user_id = ?
        ORDER BY created_at DESC
    """, (session["user"]["id"],)).fetchall()
    conn.close()
    return render_template("dashboard.html", items=my_items)


@app.route("/items")
def items():
    search = request.args.get("q", "").strip()
    category = request.args.get("category", "").strip()
    item_type = request.args.get("type", "").strip()

    query = """
        SELECT items.*, users.name AS owner_name
        FROM items JOIN users ON users.id = items.user_id
        WHERE 1=1
    """
    params = []

    if search:
        query += """ AND (items.title LIKE ? OR items.description LIKE ?
                     OR items.location LIKE ?)"""
        term = f"%{search}%"
        params.extend([term, term, term])

    if category:
        query += " AND items.category = ?"
        params.append(category)

    if item_type in ("Lost", "Found"):
        query += " AND items.item_type = ?"
        params.append(item_type)

    query += " ORDER BY items.created_at DESC"

    conn = get_db()
    results = conn.execute(query, params).fetchall()
    conn.close()

    return render_template(
        "items.html",
        items=results,
        q=search,
        category=category,
        item_type=item_type
    )


@app.route("/post", methods=["GET", "POST"])
def post_item():
    if "user" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        data = (
            request.form["title"].strip(),
            request.form["description"].strip(),
            request.form["category"],
            request.form["location"].strip(),
            request.form["item_type"],
            request.form["contact"].strip(),
            request.form.get("image_url", "").strip(),
            session["user"]["id"]
        )

        if not all(data[:7]):
            flash("Please complete all required fields.", "error")
            return redirect(url_for("post_item"))

        conn = get_db()
        conn.execute("""
            INSERT INTO items
            (title, description, category, location, item_type, contact, image_url, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, data)
        conn.commit()
        conn.close()

        flash("Your post is now visible to the campus community.", "success")
        return redirect(url_for("items"))

    return render_template("post_item.html")


@app.route("/item/<int:item_id>")
def item_detail(item_id):
    conn = get_db()
    item = conn.execute("""
        SELECT items.*, users.name AS owner_name, users.email AS owner_email
        FROM items JOIN users ON users.id = items.user_id
        WHERE items.id = ?
    """, (item_id,)).fetchone()
    conn.close()

    if not item:
        flash("Item not found.", "error")
        return redirect(url_for("items"))

    return render_template("item_detail.html", item=item)


@app.route("/item/<int:item_id>/resolve", methods=["POST"])
def resolve_item(item_id):
    if "user" not in session:
        return redirect(url_for("login"))

    conn = get_db()
    item = conn.execute("SELECT * FROM items WHERE id = ?", (item_id,)).fetchone()

    if not item or item["user_id"] != session["user"]["id"]:
        conn.close()
        flash("You can only resolve your own posts.", "error")
        return redirect(url_for("dashboard"))

    conn.execute("UPDATE items SET status = 'Resolved' WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()

    flash("Post marked as resolved.", "success")
    return redirect(url_for("dashboard"))


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
